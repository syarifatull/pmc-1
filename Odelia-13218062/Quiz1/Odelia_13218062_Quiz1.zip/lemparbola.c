/*bola dilempar dengan sudut 60 dan Vo=50m/s
program:
1. Tracking posisi (x,y) setiap 10ms
2. Hitung jarak ke tanah lagi*/

#include <stdio.h>
#include <math.h>
#define kecepatan_awal 50
#define sudut 1.0472
#define g 10

int main (void)
{
    double t, x, y;
    t = 0; /*nilai awal t*/
    x = 0; /*posisi awal horizontal*/
    y = 0; /*posisi awal vertikal*/
    do
    {
        /* code */
            t = t + 0.01; /*setiap t=0.01s*/
            x = (kecepatan_awal * cos(sudut) * t); /*posisi horizontal bola*/
            y = ((kecepatan_awal * (sin(sudut)) * t) - (0.5 * g * t * t)); /*posisi vertikal bola*/
            printf ("posisi horizontal (x): %lf\n",x);
            printf ("posisi vertikal (y): %lf\n" ,y);
            printf ("-- \n");
    } while (y >= 0/* condition */);

printf ("jarak ketika menyentuh tanah kembali adalah %f", x);
return (0);
}