// melempar bola dengan sudut 60deg v0 = 50 m/s 
// 1. tracking posisi x,y setiap 10 ms
// 2. hitung jarak terjauh ke tanah lagi

#include <stdio.h>
#include <math.h>


int main(void)
{
    double velocity = 50;
    double degree = 60;
    double gravity = 10;

    double x_pos, y_pos,
          x_vel_i, y_vel_i,
          time;

    x_pos = 0;
    y_pos = 0;

    time = 0;

    x_vel_i = velocity * cos(degree*2*(3.1415926)/360);
    y_vel_i = velocity * sin(degree*2*(3.1415926)/360);

    do 
    {

        x_pos = time*x_vel_i;
        y_pos = time*y_vel_i - 0.5*gravity*time*time;

        printf("%f\n",time);
        printf("Position x : %f\n",x_pos);
        printf("Position y : %f\n",y_pos);
        printf("\n");
        
        time += 0.01;

    } while (y_pos >= 0);

    time -= 0.01;
    printf("Last time : %f",time);

    return(0);
}